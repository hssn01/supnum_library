<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
include_once "dv.php";

$id_emprent = $_GET['id_emprent'];

$req = mysqli_query($conction, "SELECT * FROM emprent WHERE id_emprent = $id_emprent");
$row = mysqli_fetch_assoc($req);

if (isset($_POST['button'])) {
    extract($_POST);
    if (isset($matricule) && isset($id) && isset($date_retour) && isset($date_reel) && isset($date_emprunt)) {
        $req = mysqli_query($conction, "UPDATE emprent SET matricule = '$matricule' , id = '$id' , date_retour = '$date_retour' , date_reel = '$date_reel' , date_emprunt = '$date_emprunt' WHERE id_emprent = $id_emprent");
        if ($req) {
            header("location: emprent.php");
        } else {
            $message = "Emprunt non modifié";
        }
    } else {
        $message = "Veuillez remplir tous les champs !";
    }
}
?>

<div class="form">
    <a href="index.php" class="back_btn"><img src="images/back.png"> Retour</a>
    <h2>Modifier l'emprunt : <?=$row['id_emprent']?> </h2>
    <p class="erreur_message">
        <?php 
        if(isset($message)){
            echo $message ;
        }
        ?>
    </p>
    <form action="" method="POST">
        <label>Matricule</label>
        <input type="number" name="matricule" value="<?=$row['matricule']?>">
        <label>ID Livre</label>
        <input type="number" name="id" value="<?=$row['id']?>">
        <label>Date de Retour</label>
        <input type="date" name="date_retour" value="<?=$row['date_retour']?>">
        <label>Date Réelle</label>
        <input type="date" name="date_reel" value="<?=$row['date_reel']?>">
        <label>Date d'Emprunt</label>
        <input type="date" name="date_emprunt" value="<?=$row['date_emprunt']?>">
        <input type="submit" value="Modifier" name="button">
    </form>
</div>
</body>
</html>
