<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des emprunts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    
</head>
<body>
   
<div class="container">
        <a href="ajoutp.php" class="Btn_add"> <img src="images/plus.png"> Ajouter </a> 
        <div class="input-group mb-3">   
    <span class="input-group-text" id="basic-addon1"><i class="fas fa-search"></i></span>
    <input type="text" class="form-control" placeholder="Rechercher" aria-label="Username" aria-describedby="basic-addon1" id="liv" style="width: 00px;">
</div>
<table id="originalTable">
            <tr id="items">
                <th>Matricule Étudiant</th>
                <th>ID Livre</th>
                <th>Date de Retour</th>
                <th>Date Réelle</th>
                <th>Date d'Emprunt</th>
                <th>Modifier</th>
                <th>Supprimer</th>
            </tr>
            <?php 
                include_once "dv.php";
                $start=0;
                $row_pre_pag= 3;
               $recoed= mysqli_query($conction , "SELECT * FROM emprent ");
               $num_ros = mysqli_num_rows($recoed);
               $pages= ceil($num_ros/ $row_pre_pag);

                
                if(isset($_GET['page-nr'])){
                    $page = $_GET['page-nr'] -1;
                    $start = $page *$row_pre_pag;
                }
                $req = mysqli_query($conction , "SELECT * FROM emprent limit $start ,$row_pre_pag");
                if(mysqli_num_rows($req) == 0){
                    echo "Il n'y a pas encore d'étudiant ajouté !" ;
                } else {
                    $i=0;
                    while($row = mysqli_fetch_assoc($req)){
                        $i ++;
            ?>
                        <tr>
                            <td><?=$row['matricule']?></td>
                            <td><?=$row['id']?></td>
                            <td><?=$row['date_retour']?></td>
                            <td><?=$row['date_reel']?></td>
                            <td><?=$row['date_emprunt']?></td>
                            <td><a href="modp.php?id_emprent=<?=$row['id_emprent']?>"><img src="images/pen.png"></a></td>
                            <td><a href="supp.php?id_emprent=<?=$row['id_emprent']?>"><img src="images/trash.png"></a></td>
                        </tr>
                        <?php
                    }
                }
            ?>
        </table>
        <br>


        <nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item">
      <a class="page-link" href="?page-nr=1" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <?php for($contr =1 ;$contr<= $pages; $contr++){?> 
    <li class="page-item"><a class="page-link" href="?page-nr=<?=$contr; ?>"><?=$contr?></a></li>
    <?php } ?>
    <li class="page-item">
      <a class="page-link" href="?page-nr=<?=$pages; ?>" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>

<div id="searchResult"></div>
    </div>
    
   
        
    
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script type="text/javascript">
  $(document).ready(function(){
    $("#liv").keyup(function(){
        var input = $(this).val().toLowerCase();
        if(input != ""){
            $.ajax({
                url: "livesearche2.php",
                method: "post",
                data: { input: input },
                success: function(data){
                    $("#originalTable").hide(); // Hide the original table
                    $(".pagination").hide(); // Hide the pagination
                    $("#searchResult").html(data).show(); // Show the search results
                }
            });
        } else {
            $("#searchResult").hide(); // Hide the search results
            $("#originalTable").show(); // Show the original table
            $(".pagination").show(); // Show the pagination
        }
    });
});


</script>

    </div>
</body>
</html>
