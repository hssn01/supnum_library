<?php


$conction= new mysqli("localhost","root","","pi");
if(!$conction){
    die(mysqli_error($conction));

}


?>