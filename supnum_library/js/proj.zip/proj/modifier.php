<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php

         
          include_once "dv.php";
         
          $matricule = $_GET['matricule'];
          
          $req = mysqli_query($conction , "SELECT * FROM etudiants WHERE matricule = $matricule");
          $row = mysqli_fetch_assoc($req);


       if(isset($_POST['button'])){
           
           extract($_POST);
           if(isset($matricule) && isset($nom) && isset($niveau) && isset($niveau) && $specialite){
               $req = mysqli_query($conction, "UPDATE etudiants SET matricule = '$matricule' , nom = '$nom' , prenom = '$prenom' , niveau = '$niveau' , specialite = '$specialite' WHERE matricule = $matricule");
                if($req){
                    header("location: index.php");
                }else {
                    $message = "etudiants non modifié";
                }

           }else {
               
               $message = "Veuillez remplir tous les champs !";
           }
       }
    
    ?>

    <div class="form">
        <a href="index.php" class="back_btn"><img src="images/back.png"> Retour</a>
        <h2>Modifier l'etudient : <?=$row['nom']?> </h2>
        <p class="erreur_message">
           <?php 
              if(isset($message)){
                  echo $message ;
              }
           ?>
        </p>
        <form action="" method="POST">
            <label>Matricule</label>
            <input type="number" name="matricule" value="<?=$row['matricule']?>">
            <label>Nom</label>
            <input type="text" name="nom" value="<?=$row['nom']?>">
            <label>Prénom</label>
            <input type="text" name="prenom" value="<?=$row['prenom']?>">
            <label>Niveaux</label>
            <input type="text" name="niveau" value="<?=$row['niveau']?>">
            <label>Specialite</label>
            <input type="text" name="specialite" value="<?=$row['specialite']?>">
            <input type="submit" value="Modifier" name="button">
        </form>
    </div>
</body>
</html>