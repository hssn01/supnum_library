  function schow_add(){

    Commande : toastr["info"]("Ajouter avec succès","ajouter etudiant")

  toastr.options = {
    "closeButton": vrai,
      "debug": faux,
      "newestOnTop": faux,
    "progressBar": faux,
      "positionClass": "toast-en haut à droite",
      "preventDuplicates": faux,
      "onclick": nul,
      "showDuration": "300",
      "hideDuration": "1000",
      "timeOut": "5000",
      "extendedTimeOut": "1000",
      "showEasing": "swing",
      "hideEasing": "linéaire",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
    }

  




}


    

