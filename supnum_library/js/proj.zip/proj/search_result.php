<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h1>Search Results</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>Matricule</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Niveaux</th>
                    <th>Specialite</th>
                    <th>Modifier</th>
                    <th>Supprimer</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include_once "dv.php";
                if(isset($_GET['input'])){
                    $input = $_GET['input'];
                    $query = "SELECT * FROM etudiants WHERE nom LIKE '%$input%'";
                    $result = mysqli_query($conction, $query);
                    
                    if(mysqli_num_rows($result) > 0){
                        while($row = mysqli_fetch_assoc($result)){
                            echo "<tr>";
                            echo "<td>" . $row['matricule'] . "</td>";
                            echo "<td>" . $row['nom'] . "</td>";
                            echo "<td>" . $row['prenom'] . "</td>";
                            echo "<td>" . $row['niveau'] . "</td>";
                            echo "<td>" . $row['specialite'] . "</td>";
                            echo "<td><a href='modifier.php?matricule=" . $row['matricule'] . "'><img src='images/pen.png'></a></td>";
                            echo "<td><a href='suppeime.php?matricule=" . $row['matricule'] . "'><img src='images/trash.png'></a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>Aucune personne trouvée avec ce nom.</td></tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
