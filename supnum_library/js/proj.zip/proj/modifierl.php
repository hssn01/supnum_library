<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
include_once "dv.php";

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Fetch book data
    $query = "SELECT * FROM livres WHERE id = ?";
    $stmt = mysqli_prepare($conction, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if($row = mysqli_fetch_assoc($result)) {
        if(isset($_POST['button'])) {
            $isbn = $_POST['isbn'];
            $hauteur = $_POST['hauteur'];
            $editeur = $_POST['editeur'];
            $titre = $_POST['titre'];
            $nbrpage = $_POST['nbrpage'];
            $adition = $_POST['adition'];
            $nbrexmp = $_POST['nbrexmp'];
            $datepubli = $_POST['datepubli'];
            
            // Update book data
            $update_query = "UPDATE livres SET isbn = ?, hauteur = ?, editeur = ?, titre = ?, nbrpage = ?, adition = ?, nbrexmp = ?, datepubli = ? WHERE id = ?";
            $update_stmt = mysqli_prepare($conction, $update_query);
            mysqli_stmt_bind_param($update_stmt, "isssssisi", $isbn, $hauteur, $editeur, $titre, $nbrpage, $adition, $nbrexmp, $datepubli, $id);
            $success = mysqli_stmt_execute($update_stmt);
            
            if($success) {
                header("location: livre.php");
                exit; // Ensure script execution stops after redirect
            } else {
                $message = "Livre non modifié.";
            }
        }
    } else {
        // Handle invalid ID
        die("Invalid ID.");
    }
} else {
    // Handle missing ID
    die("ID not provided.");
}
?>


    <div class="form">
        <a href="livre.php" class="back_btn"><img src="images/back.png"> Retour</a>
        <h2>Modifier le livre : <?=$row['titre']?> </h2>
        <p class="erreur_message">
           <?php 
              if(isset($message)){
                  echo $message ;
              }
           ?>
        </p>
        <form action="" method="POST">
            <label>ISBN</label>
            <input type="number" name="isbn" value="<?=$row['isbn']?>">
            <label>Auteur</label>
            <input type="text" name="hauteur" value="<?=$row['hauteur']?>">
            <label>Éditeur</label>
            <input type="text" name="editeur" value="<?=$row['editeur']?>">
            <label>Titre</label>
            <input type="text" name="titre" value="<?=$row['titre']?>">
            <label>Nombre de page</label>
            <input type="text" name="nbrpage" value="<?=$row['nbrpage']?>">
            <label>Adition</label>
            <input type="number" name="adition" value="<?=$row['adition']?>">
            <label>Nombre exempilaire</label>
            <input type="number" name="nbrexmp" value="<?=$row['nbrexmp']?>">
            <label>Date publie</label>
            <input type="date" name="datepubli" value="<?=$row['datepubli']?>">
            <input type="submit" value="Modifier" name="button">
        </form>
    </div>
</body>
</html>