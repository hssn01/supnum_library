<?php
include_once "dv.php";

if(isset($_POST['input'])){
    $input = $_POST['input'];
    $query = "SELECT * FROM emprent WHERE id_emprent LIKE '%$input%'
     OR matricule LIKE '%$input%' OR Date_retour LIKE '%$input%' 
    OR id LIKE '%$input%' limit 3";
    $result = mysqli_query($conction, $query);

    if(mysqli_num_rows($result) > 0){
        ?>
        <table id="">
    <tr id="items">
    <th>Matricule Étudiant</th>
                <th>ID Livre</th>
                <th>Date de Retour</th>
                <th>Date Réelle</th>
                <th>Date d'Emprunt</th>
                <th>Modifier</th>
                <th>Supprimer</th>
        <th>Supprimer</th>
    </tr>
    <?php 
    $req = mysqli_query($conction , "SELECT * FROM emprent");
    if(mysqli_num_rows($req) == 0){
        echo "<tr><td colspan='11'>Il n'y a pas encore de livre ajouté !</td></tr>";
    } else {
        while($row = mysqli_fetch_assoc($req)){
            ?>
            <tr>
            <td><?=$row['matricule']?></td>
                            <td><?=$row['id']?></td>
                            <td><?=$row['date_retour']?></td>
                            <td><?=$row['date_reel']?></td>
                            <td><?=$row['date_emprunt']?></td>
                            <td><a href="modp.php?id_emprent=<?=$row['id_emprent']?>"><img src="images/pen.png"></a></td>
                            <td><a href="supp.php?id_emprent=<?=$row['id_emprent']?>"><img src="images/trash.png"></a></td>
                        </tr>
            <?php
        }
    }
    ?>
</table>

        <?php
    } else {
        echo "<h6 class='text-danger text-center mt-m3'>Aucun livre trouvé avec ce critère de recherche.</h6>";
    }
}
?>
